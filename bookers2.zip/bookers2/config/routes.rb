Rails.application.routes.draw do
  devise_for :users

root to: 'homes#top'
get 'home/about', to: 'homes#about'
post 'users/:id', to: 'book#create'

resources :users, only: [:index, :show, :edit, :update, :create]
resources :books, only: [:new, :index, :show, :create, :edit, :update, :destroy]
end
