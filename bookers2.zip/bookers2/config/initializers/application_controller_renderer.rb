# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '7db851ab28364409569f772567591a677f2f15b1f2e55be850e82fcc17836ef359d6a02762779a0d0c1b470b178ff344f8b06e5fcd31effd89a21152e93a2fb7'                      