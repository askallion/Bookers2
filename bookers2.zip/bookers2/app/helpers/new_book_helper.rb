module NewBookHelper
end
