class UsersController < ApplicationController
 before_action :correct_user, only: [:edit, :update]


  def index
    @book = Book.new
    @users = User.all
  end

  def create
  @user=User.new
    name:params[:name]
    image_name:"default_user.jpg"
  end

  def show
    @book = Book.new
    @user = User.find(params[:id])
    @books = @user.books.all
  end


  def update
    @user = User.find(params[:id])
    if @user.update(user_params)
      flash[:notice] = "You have updated user successfully."
      redirect_to user_path(@user.id)
    else
      @users = User.all
      render :edit
    end
  end


  def edit
    @users = User.all
    @user = User.find(params[:id])
  end

  private

  def user_params
    params.require(:user).permit(:name, :introduction, :profile_image)
  end

  def book_params
    params.permit(:title, :body, :user_id)
  end

  def correct_user
    @user = User.find(params[:id])
    redirect_to user_path(current_user) unless @user == current_user
  end

end



