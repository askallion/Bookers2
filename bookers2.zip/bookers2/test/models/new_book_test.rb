require 'test_helper'

class NewBookTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
